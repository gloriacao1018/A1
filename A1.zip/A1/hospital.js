//part 1

let hospital = {
    hospitalName: "Oakville General",
    patients:[
        {
            id:"31421",
            fullName:"Ashley Adams",
            dateOfBirth:"10-18-2000",
            symptoms:["cough","headache","muscle ache"]
        },
        {
            id:"31322",
            fullName:"Jamie Smith",
            dateOfBirth:"09-20-1998",
            symptoms:["cough","nausea","muscle ache"]
        },
        {
            id:"31422",
            fullName:"Kevin Young",
            dateOfBirth:"03-20-1972",
            symptoms:["runny nose","headache","strap throat"]
        },

    ]
}

//part 2

function showPatients(hospitalData) {
    let result = "<h1>" + hospitalData.hospitalName + "</h1>\n";
  
    for (let i = 0; i < hospitalData.patients.length; i++) {
      const patient = hospitalData.patients[i];
  
      result += "<h2>" + patient.fullName + ", " + patient.dateOfBirth + "</h2>\n";
  
      result += "<ul>\n";
      for (let j = 0; j < patient.symptoms.length; j++) {
        result += "<li>" + patient.symptoms[j] + "</li>\n";
      }
      result += "</ul>\n";
    }
  
    return result;  
  }

let hospitalData = {
    hospitalName: "Oakville General",
    patients:[
        {
            id:"31421",
            fullName:"Ashley Adams",
            dateOfBirth:"10-18-2000",
            symptoms:["cough","headache","muscle ache"]
        },
        {
            id:"31322",
            fullName:"Jamie Smith",
            dateOfBirth:"09-20-1998",
            symptoms:["cough","nausea","muscle ache"]
        },
        {
            id:"31422",
            fullName:"Kevin Young",
            dateOfBirth:"03-20-1972",
            symptoms:["runny nose","headache","strap throat"],
        },

    ]
}

let resultHTML = showPatients(hospitalData);
console.log(resultHTML);

//part 3
let patientRecords = [
  { id: "31421", fullName: "Ashley Adams" },
  { id: "31322", fullName: "Jamie Smith" },
  { id: "31422", fullName: "Kevin Young" }
];

function getPatient(patientRecords) {
  if (patientRecords.length === 0) {
    return "No patient records available.";
  }

  let randomIndex = Math.floor(Math.random() * patientRecords.length);
  let randomPatient = patientRecords[randomIndex];
  return randomPatient.id;
}

let randomPatientID = getPatient(patientRecords);
console.log("Random Patient ID:", randomPatientID);
